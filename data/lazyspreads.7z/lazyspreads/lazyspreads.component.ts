import {CollectionViewer, DataSource} from '@angular/cdk/collections';
import {ChangeDetectionStrategy, Component} from '@angular/core';
import {BehaviorSubject, Observable, Subscription} from 'rxjs';
import {HttpClient, HttpClientModule, HttpHandler, HttpParams} from '@angular/common/http';

/** @title Virtual scroll with a custom data source */
@Component({
  selector: 'app-lazyspreads',
  templateUrl: './lazyspreads.component.html',
  styleUrls: ['./lazyspreads.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LazyspreadsComponent {

  ds: MyDataSource;
  constructor(private httpClient: HttpClient) {
    this.ds = new MyDataSource(httpClient);
  }
}

export interface  Spread {
  docId?: string;
}

export class MyDataSource extends DataSource<Spread | undefined> {
  private _length = 20000;
  private _pageSize = 20;
  private _cachedData = Array.from<Spread>({length: this._length});
  private dataFetched = false;
  private _dataStream = new BehaviorSubject<(Spread | undefined)[]>(this._cachedData);
  private _subscription = new Subscription();
  private allSpreads = [];
  private _fetchedPages = new Set<number>();
  constructor (private httpClient: HttpClient){
    super();
  };

  connect(collectionViewer: CollectionViewer): Observable<(Spread | undefined)[]> {
    this._subscription.add(collectionViewer.viewChange.subscribe(range => {

      const startPage = this._getPageForIndex(range.start);
      const endPage = this._getPageForIndex(range.end - 1);
      for (let i = startPage; i <= endPage; i++) {
        this._fetchPage(i);
      }
    }));
    return this._dataStream;
  }

  disconnect(): void {
    this._subscription.unsubscribe();
  }

  private _getPageForIndex(index: number): number {
    return Math.floor(index / this._pageSize);
  }

  private _fetchPage(page: number) {
    if (this._fetchedPages.has(page)) {
      return;
    }
    this._fetchedPages.add(page);


    this.dataFetched = true;
    const start: number = page * this._pageSize;
console.log("pobieram dla strony: " + page + " od idx: " + start + " do idx: " + (start+this._pageSize));
    this.httpClient
      //?_start=' + start + '&_end=' + start + this._pageSize
      .get('http://localhost:3001/spreads')
      .toPromise()
      .then((data: any) => {
        this.allSpreads = data;
        this.prepareData(page);
      })
      .catch((error) => {
        throw 'Data Loading Error';
      });

    // Use `setTimeout` to simulate fetching data from server.
   // setTimeout(() => {
   //    this._cachedData.splice(page * this._pageSize, this._pageSize,
   //      ...Array.from({length: this._pageSize})
   //        .map((_, i) => `Item #${page * this._pageSize + i}`));
   //    this._dataStream.next(this._cachedData);
   //  }, Math.random() * 1000 + 200);
  }


  prepareData(page: number) {
    // this.allSpreads.splice(page * this._pageSize, this._pageSize,
    //   ...Array.from({length: this._pageSize})
    //     .map((_, i) => `Item #${page * this._pageSize + i}`));
    // this._dataStream.next(this.allSpreads);


    var newArr = new Array<any>(this._pageSize);
    console.log("PREPARING, PAGE=" + page);
    for (var i=0; i<this._pageSize; i++) {
      newArr[i] = this.allSpreads[page * this._pageSize + i];
    }
    this._dataStream.next(newArr);
  }


}
